﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr" dir="ltr">
<head>
	<meta content="text/html; charset=UTF-8" http-equiv="content-type"/>
	<link rel="stylesheet" type="text/css" href="style.css" />

	<title>Bievenue chez SuperVod !</title>
</head>
<body>
	<div id="header">
		<img class="logoLeft" src="images/logo.jpg" width="180px" alt="" />
		<h1 id="title">
			SuperVod : les meilleures séries sont chez nous !
		</h1>
		<img class="logoRight" src="images/logo.jpg" width="180px" alt="" />
	</div>
	<div id="speedbar">
		<ul>
			<li><a href="accueil.php">Nouveautés</a></li>
			<li><a href="rechercheserie.php">Recherche d'une série</a></li>
			<li><a href="rechercheepisodes.php">Recherche d'un épisode</a></li>
			<li><a href="telechargement.php">Téléchargement</a></li>
			<li><a href="prive.php">Administrateur</a></li>
		</ul>
	</div>
